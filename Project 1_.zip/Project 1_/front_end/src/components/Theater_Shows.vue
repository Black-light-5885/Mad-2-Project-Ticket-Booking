<template>
  <div>
    <div class="nav-fnav">
      <div class="left">
        <img src="./dummy/logo3.png" alt="" />
        <input
          type="text"
          placeholder="Search for Movies, Theaters, shows etc.."
        />
      </div>

      <div class="right">
        <button>
          <router-link to="/login"><a>Logout</a></router-link>
        </button>
      </div>
    </div>
    <div class="nav-sec-nav">
      <div class="s-left">
        <router-link
          :to="{ name: 'User_Home', params: { uer_name: this.user_name } }"
          ><a>Home</a></router-link
        >

        <router-link
          :to="{
            name: 'User_Movies',
            params: { user_name: this.user_name },
          }"
          ><a>Movies</a></router-link
        >

        <router-link
          :to="{
            name: 'User_Theaters',
            params: { user_name: this.user_name },
          }"
          ><a>Theaters</a></router-link
        >
      </div>
      <div class="s-right">
        <router-link
          :to="{
            name: 'User_Bookings',
            params: { user_name: this.user_name },
          }"
        >
          <a>Bookings</a></router-link
        >
        <router-link
          :to="{
            name: 'User_Profile',
            params: { user_name: this.user_name },
          }"
        >
          <a>Profile</a></router-link
        >
      </div>
    </div>
    <div class="Headline">
      <h2>Show Details of : {{ this.theater }}</h2>
    </div>
    <div class="container">
      <div class="no-shows" v-if="shows.length === 0">
        <h2>Currently No show for this Theater !</h2>
      </div>
      <div class="content">
        <div class="card" v-for="show in shows" :key="show.id">
          <div class="card-content">
            <div class="theater-name">
              <h2 class="name">{{ show.name }}</h2>
            </div>
            <div class="capacity">
              <h4><span>Date :</span> {{ show.date }}</h4>
              <h4><span>Time :</span> {{ show.time }}</h4>
            </div>
            <div class="capacity">
              <h4><span>City :</span> {{ show.place }}</h4>
              <h4><span>Location :</span> {{ show.location }}</h4>
            </div>
            <div class="capacity">
              <h4><span>Movie :</span> {{ show.movie }}</h4>
              <h4><span>Theater :</span> {{ show.theater }}</h4>
            </div>
            <div class="capacity">
              <h4>Price : ₹{{ show.price }}</h4>
              <h4>Available Seats : {{ show.available }}</h4>
            </div>
            <div class="button">
              <button class="delete">Details</button>
              <button class="edit" @click="bookTicket(show)">
                Book Ticket
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import Swal from "sweetalert2";
export default {
  props: {
    t_id: {
      type: String,
      required: true,
    },
    user_name: {
      type: String,
      required: true,
    },
  },
  data() {
    return {
      token: "",
      user: {
        full_name: "",
        username: "",
        admin: null,
      },
      shows: [],
      theater: "",
    };
  },
  methods: {
    bookTicket(show) {
      this.$router.push({
        name: "Book_Ticket",
        params: { s_id: String(show.id), user_name: this.user_name },
      });
    },
    getShows() {
      fetch("http://127.0.0.1:5000/app/api/show", {
        method: "GET",
        headers: {
          Authorization: `Bearer ${this.token}`,
        },
      })
        .then((res) => {
          return res.json();
        })
        .then((data) => {
          if (data.msg === "Token has expired") {
            Swal.fire({
              icon: "error",
              title: "Session Exparired",
              text: "Login again",
            });
            this.$router.push("/login");
          }
          for (let show of data.shows) {
            if (show.theater_id == Number(this.t_id)) {
              this.theater = show.theater;

              this.shows.push(show);
            }
          }
        });
    },
  },
  created() {
    const token = localStorage.getItem("token");
    if (token == null) {
      this.$router.push("/login");
    }
    this.token = token;
    this.getShows();
  },
};
</script>

<style scoped>
* {
  margin: 0%;
  padding: 0%;
}

.nav-fnav {
  display: flex;
  justify-content: center;
  justify-content: space-around;
  padding: 15px;
  color: white;
  background-color: rgb(42, 42, 68);
}

.nav-fnav .left {
  display: flex;
  align-items: center;
}

.left input {
  margin-inline: 11px;
  width: 320px;
  height: 33px;
  border: none;
  outline: none;
  text-align: center;
  border-radius: 3px;
}

.nav-fnav .right {
  display: flex;
  align-items: center;
}
.right a {
  margin-inline: 2px;
  font-size: 15px;
  text-decoration: none;
  color: white;
}
.left img {
  width: 170px;
  height: 60px;
}
.right button {
  margin-inline: 2px;
  width: 80px;
  height: 27px;
  border: none;
  border-radius: 5px;
  background-color: rgb(19, 131, 223);
  color: white;
  text-decoration: none;
  cursor: pointer;
  transition: 0.3s;
}
.right button:hover {
  background-color: #ff7200;
}
.nav-sec-nav {
  display: flex;
  justify-content: center;
  justify-content: space-around;
  padding: 10px;
  background-color: rgb(26, 26, 48);
  color: white;
}

.nav-sec-nav .s-left {
  display: flex;
}
.nav-sec-nav .s-right {
  display: flex;
  text-decoration: none;
}
.nav-sec-nav a:hover {
  color: brown;
  cursor: pointer;
  font-weight: bold;
  text-decoration: none;
}
.s-left a {
  margin-inline-start: 18px;
  text-decoration: none;
  color: white;
}

.s-right a {
  margin-inline-start: 18px;
  text-decoration: none;
  color: white;
}
.Headline {
  padding: 10px;
  background-color: #3ca872af;
}
.Headline h2 {
  color: rgb(42, 42, 68);
}

.container {
  justify-content: center;
  align-items: center;
  min-height: 100vh;
}
.card {
  background: rgb(42, 42, 68);
  border: 3px solid #0ef;
  border-radius: 10px;
  width: 550px;
  height: 360px;
  margin-top: 15px;
}
.content {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
}

.container .no-shows {
  display: flex;
  justify-content: center;
  justify-content: space-evenly;
  align-items: center;
  margin-top: 50px;
}
.card .card-content {
  position: relative;
  display: flex;
  align-items: center;
  flex-direction: column;
  padding: 10px;
}
.card .theater-name {
  display: flex;
  align-items: center;
  flex-direction: column;
  margin-top: 10px;
  color: #fff;
}
.theater-name .name {
  font-size: 40px;
  font-weight: 600;
}

.theater-name .location {
  font-size: 15px;
  font-weight: 400;
}
.card .capacity {
  display: flex;
  justify-content: space-between;
  margin-top: 18px;
  color: #fff;
}
.card .capacity span {
  color: #ff7200;
}
.card .capacity h4 {
  padding: 8px 40px;
  border-radius: 20px;
}
.card .capacity span {
  color: #ff7200;
}
.card .button {
  display: flex;
  justify-content: space-around;
  width: 110%;
  margin-top: 20px;
}
.card .button button {
  background: #0ef;
  border: none;
  outline: none;
  color: #000;
  font-weight: 600;
  padding: 8px 22px;
  border-radius: 20px;
  font-size: 14px;
  cursor: pointer;
  transition: 0.3s;
}
.card .button button:hover {
  background: #fff;
}
</style>
