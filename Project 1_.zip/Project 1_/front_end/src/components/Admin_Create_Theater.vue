<template>
  <div>
    <div class="nav-fnav">
      <div class="left">
        <img src="./dummy/logo3.png" alt="" />
        <input
          type="text"
          placeholder="Search for Movies, Theaters, shows etc.."
        />
      </div>

      <div class="right">
        <button>
          <router-link to="/login"><a>Logout</a></router-link>
        </button>
      </div>
    </div>
    <div class="nav-sec-nav">
      <div class="s-left">
        <router-link
          :to="{ name: 'Admin_Home', params: { uer_name: this.user_name } }"
          ><a>Home</a></router-link
        >
        <router-link
          :to="{
            name: 'Admin_Movies',
            params: { user_name: this.user_name },
          }"
          ><a>Movies</a></router-link
        >
        <router-link
          :to="{
            name: 'Admin_Theaters',
            params: { user_name: this.user_name },
          }"
          ><a>Theaters</a></router-link
        >
        <router-link
          :to="{
            name: 'Admin_Shows',
            params: { user_name: this.user_name },
          }"
          ><a>Shows</a></router-link
        >
      </div>
      <div class="s-right">
        <router-link
          :to="{
            name: 'Create_Movie',
            params: { user_name: this.user_name },
          }"
          ><a>Add Movie</a></router-link
        >
        <router-link
          :to="{
            name: 'Create_Theater',
            params: { user_name: this.user_name },
          }"
          ><a>Add Theater</a></router-link
        >
        <router-link
          :to="{
            name: 'Create_Show',
            params: { user_name: this.user_name },
          }"
          ><a>Add Show</a></router-link
        >
        <router-link
          :to="{
            name: 'User_Profile',
            params: { user_name: this.user_name },
          }"
        >
          <a>Profile</a></router-link
        >
      </div>
    </div>
    <div class="main">
      <h1>Create New Theater</h1>
    </div>
    <div class="container">
      <div class="create-movie">
        <h2>New Theater</h2>
        <form @submit.prevent="CreateTheater">
          <input
            type="text"
            placeholder="Enter Theater Name Here"
            v-model="theater_name"
          />
          <input type="text" placeholder="Enter Place.." v-model="place" />
          <input
            type="text"
            placeholder="Enter Location..."
            v-model="location"
          />
          <input
            type="number"
            placeholder="Enter Capcity..."
            max="300"
            v-model="capacity"
          />
          <button class="btn_submit">Create Theater</button>
        </form>
      </div>
    </div>
  </div>
</template>

<script>
import Swal from "sweetalert2";
export default {
  props: {
    user_name: {
      type: String,
      required: true,
    },
  },
  data() {
    return {
      token: "",
      user: {
        full_name: "",
        username: "",
        admin: null,
      },
      theater_name: "",
      place: "",
      location: "",
      capacity: "",
    };
  },
  methods: {
    getUser_details(token_) {
      fetch(`http://127.0.0.1:5000/app/api/user/${this.user_name}`, {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token_}`,
        },
      })
        .then((res) => {
          return res.json();
        })
        .then((data) => {
          this.user.full_name = data.full_name;
          this.user.admin = data.admin;
          if (data.msg === "Token has expired") {
            Swal.fire({
              icon: "error",
              title: "Session Exparired",
              text: "Login again",
            });
            this.$router.push("/login");
          }
          console.log(data);
        });
    },
    CreateTheater: function () {
      const data = {
        name: this.theater_name,
        place: this.place,
        location: this.location,
        capacity: this.capacity,
      };

      fetch("http://127.0.0.1:5000/app/api/theater", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${this.token}`,
        },
        body: JSON.stringify(data),
      })
        .then((res) => {
          return res.json();
        })
        .then((data) => {
          if (data.msg === "Token has expired") {
            Swal.fire({
              icon: "error",
              title: "Session Exparired",
              text: "Login again",
            });
            this.$router.push("/login");
          }
          Swal.fire({
            position: "top-end",
            icon: "success",
            title: "Theater Create successfully!",
            showConfirmButton: false,
            timer: 1500,
          });
          this.$router.push({
            name: "Admin_Theaters",
            params: { user_name: this.user_name },
          });
        })
        .catch((error) => {
          if (error.message.startsWith("Token")) {
            alert("Session Expaired. Please Login again!");
            this.$route.put("/login");
          } else {
            console.log(error);
          }
        });
    },
  },
  created() {
    const token = localStorage.getItem("token");
    if (token == null) {
      this.$router.push("/login");
    }
    this.getUser_details(token);
    this.token = token;
  },
};
</script>

<style scoped>
* {
  margin: 0%;
  padding: 0%;
}

.nav-fnav {
  display: flex;
  justify-content: center;
  justify-content: space-around;
  padding: 15px;
  color: white;
  background-color: rgb(42, 42, 68);
}

.nav-fnav .left {
  display: flex;
  align-items: center;
}

.left input {
  margin-inline: 11px;
  width: 320px;
  height: 33px;
  border: none;
  outline: none;
  text-align: center;
  border-radius: 3px;
}

.nav-fnav .right {
  display: flex;
  align-items: center;
}
.right a {
  margin-inline: 2px;
  font-size: 15px;
  text-decoration: none;
  color: white;
}
.left img {
  width: 170px;
  height: 60px;
}
.right button {
  margin-inline: 2px;
  width: 80px;
  height: 27px;
  border: none;
  border-radius: 5px;
  background-color: rgb(19, 131, 223);
  color: white;
  text-decoration: none;
  cursor: pointer;
  transition: 0.3s;
}
.right button:hover {
  background-color: #ff7200;
}
.nav-sec-nav {
  display: flex;
  justify-content: center;
  justify-content: space-around;
  padding: 10px;
  background-color: rgb(26, 26, 48);
  color: white;
}

.nav-sec-nav .s-left {
  display: flex;
}
.nav-sec-nav .s-right {
  display: flex;
  text-decoration: none;
}
.nav-sec-nav a:hover {
  color: brown;
  cursor: pointer;
  font-weight: bold;
  text-decoration: none;
}
.s-left a {
  margin-inline-start: 18px;
  text-decoration: none;
  color: white;
}

.s-right a {
  margin-inline-start: 18px;
  text-decoration: none;
  color: white;
}
.main img {
  width: 100%;
  margin-top: 10px;
}
.main h1 {
  padding: 22px;
}
.container {
  display: flex;
  justify-content: center;
  align-items: center;
}
.create-movie {
  margin-top: 20px;
  width: 320px;
  background: gray;
  border: 2px solid rgba(153, 153, 153, 0.2);
  backdrop-filter: blur(20px);
  box-shadow: 0 0 10 rgba(0, 0, 0, 0.2);
  color: #ffff;
  border-radius: 10px;
  padding: 30px 40px;
}
.create-movie input {
  width: 240px;
  height: 35px;
  margin-left: 25px;
  background: transparent;
  border-bottom: 1px solid #ff7200;
  border-top: none;
  border-right: none;
  border-left: none;
  color: rgb(0, 0, 0);
  font-size: 15px;
  letter-spacing: 1px;
  margin-top: 30px;
  font-family: sans-serif;
}
.create-movie input:focus {
  outline: none;
}
::placeholder {
  color: rgb(0, 0, 0);
  font-family: Arial, Helvetica, sans-serif;
}

.btn_submit {
  width: 240px;
  height: 40px;
  background: #ff7200;
  border: none;
  margin-top: 30px;
  margin-left: 25px;
  color: #fff;
  font-size: 18px;
  border-radius: 10px;
  font-family: Arial, Helvetica, sans-serif;
  cursor: pointer;
  transition: 0.3s ease;
  font-weight: bold;
}
.btn_submit:hover {
  color: #2ed755;
  background: #fff;
}
.btn_submit:disabled {
  color: #ffffff;
  background-color: #ffffff;
}
</style>
