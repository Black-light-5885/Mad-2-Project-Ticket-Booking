<template>
  <div class="body">
    <div class="wrapper">
      <h1>Register Here</h1>
      <div class="error" v-if="error">
        <p>{{ error_msg }}</p>
      </div>
      <div class="input-box">
        <input
          type="text"
          name="first_name"
          v-model="full_name"
          placeholder="Enter Full Name"
          required
        />
      </div>
      <div class="input-box">
        <input
          type="text"
          v-model="user_name"
          placeholder="Enter New User Name"
          required
        />
      </div>
      <div class="input-box">
        <input
          type="email"
          v-model="email"
          placeholder="Enter New Email-ID"
          required
        />
      </div>
      <div class="input-box">
        <input
          type="password"
          v-model="password"
          placeholder="Enter New Password"
        />
      </div>
      <div class="condition-check">
        <label v-bind:style="{ color: conditions.length }">
          Password should be at least 8 characters</label
        ><br />
        <label v-bind:style="{ color: conditions.capital }"
          >Password must contains at least one Capital letter</label
        ><br />
        <label v-bind:style="{ color: conditions.number }"
          >Password must contains at least one number</label
        ><br />
      </div>
      <div class="input-box">
        <input
          type="password"
          v-model="password_2"
          v-bind:style="{ 'border-bottom': password_match }"
          placeholder="Confirm Your Password"
        />
      </div>
      <div class="condition-check">
        <label v-bind:style="{ color: conditions.match }"
          >Password doesn't match</label
        >
        <div class="input-box">
          <input type="text" placeholder="Admin Key" v-model="admin_key" />
        </div>
      </div>

      <button class="btn_submit" :disabled="all_good" @click="register_">
        Sign Up
      </button>
      <div class="register-link">
        <p class="back_to_register">
          Alredy have account?
          <a href="/login" class="register"> Login</a> Here
        </p>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      full_name: "",
      user_name: "",
      password: "",
      password_2: "",
      email: "",
      conditions: {
        length: "#ff7200",
        capital: "#ff7200",
        number: "#ff7200",
        match: "#ff7200",
      },
      password_match: "1px solid #ff7200",
      all_good: true,
      admin_key: "",
      error: false,
      error_msg: "",
    };
  },
  methods: {
    conditionsCheck() {
      if (
        this.full_name.length > 3 &&
        this.user_name.length > 4 &&
        this.email != ""
      ) {
        return true;
      } else {
        return false;
      }
    },
    register_: async function () {
      const user_data = {
        full_name: this.full_name,
        email: this.email,
        user_name: this.user_name,
        password: this.password,
        admin: false,
      };
      if (this.admin_key === "1234") {
        user_data.admin = true;
      }
      let all_good = this.all_good;
      if (!all_good && this.conditionsCheck()) {
        await fetch("http://127.0.0.1:5000/app/api/user", {
          headers: {
            "Content-Type": "application/json",
          },
          method: "POST",
          body: JSON.stringify(user_data),
        })
          .then((res) => {
            if (res.ok) {
              return res.json();
            } else {
              throw new Error("Something wrong");
            }
          })
          .then((data) => {
            console.log(data);
            this.$router.push("/login");
          })
          .catch((error) => {
            console.log(error);
          });
      } else {
        console.log("Something wrong");
        this.error = true;
        this.error_msg = "You need to fill other details!";
      }
      console.log(this.full_name, this.user_name, this.password);
    },
    conditions_check: function () {
      for (let ele in this.conditions) {
        if (this.conditions[ele] == "#ff7200") {
          this.all_good = true;
        }
      }
    },
  },

  watch: {
    password(nv) {
      this.conditions.length = "#ff7200";
      this.conditions.capital = "#ff7200";
      this.conditions.number = "#ff7200";
      this.all_good = true;
      this.conditions.match = "#ff7200";
      this.password_match = "2px solid #ff7200";
      if (nv.length >= 8) this.conditions.length = "hsl(120, 95%,65%)";
      for (let i = 0; i < nv.length; i++) {
        let uv = nv.charCodeAt(i);
        if (uv >= 65 && uv <= 90) this.conditions.capital = "hsl(120, 95%,65%)";
        if (uv >= 48 && uv <= 57) this.conditions.number = "hsl(120, 95%,65%)";
      }
      if (this.password_2 != "" && this.password_2 === nv) {
        this.password_match = "2px solid #0db02e";
        this.conditions.match = "hsl(120, 95%,65%)";
        this.all_good = false;
      }
      this.conditions_check();
    },

    password_2(nv2) {
      this.all_good = true;
      this.conditions.match = "#ff7200";
      this.password_match = "2px solid #ff7200";
      if (this.password_2 != "" && this.password === nv2) {
        this.password_match = "2px solid #0db02e";
        this.conditions.match = "hsl(120, 95%,65%)";
        this.all_good = false;
      }
      this.conditions_check();
    },
  },
};
</script>

<style scoped>
* {
  margin: 0%;
  padding: 0%;
  box-sizing: border-box;
  font-family: sans-serif;
}
.body {
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 97.5vh;
  background: url(./dummy/check.jpg) no-repeat;
  background-size: cover;
  background-position: center;
}
.wrapper {
  width: 520px;
  background: transparent;
  border: 2px solid rgba(255, 255, 255, 0.2);
  backdrop-filter: blur(20px);
  box-shadow: 0 0 10 rgba(0, 0, 0, 0.2);
  color: #ffff;
  border-radius: 10px;
  padding: 1px 30px;
}
.wrapper h1 {
  font-size: 36px;
  text-align: center;
}

.wrapper .input-box {
  position: relative;
  width: 100%;
  height: 40px;
  margin: 20px 0;
}
.input-box input {
  width: 100%;
  height: 100%;
  background: transparent;
  border: none;
  outline: none;
  border: 2px solid rgba(255, 255, 255, 0.2);
  border-radius: 40px;
  font-size: 16px;
  color: #ffff;
  padding: 10px 25px 10px 10px;
}
.input-box input::placeholder {
  color: #ffff;
}

.condition-check label {
  justify-content: end;
  font-size: 12px;
  font-weight: 600;
}

.wrapper .remember-forgot {
  display: flex;
  justify-content: space-between;
  font-size: 14.5px;
  margin: -15px 0 15px;
}
.remember-forgot label input {
  accent-color: #ffff;
  margin-right: 3px;
}
.remember-forgot a {
  color: white;
  text-decoration: none;
}
.remember-forgot a:hover {
  color: rgb(117, 231, 24);
  text-decoration: underline;
}
.error {
  color: red;
  margin-top: 5px;
  font-weight: 400;
}
.wrapper .btn_submit {
  width: 100%;
  height: 45px;
  background: #fff;
  border: none;
  outline: none;
  border-radius: 40px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
  cursor: pointer;
  font-size: 16px;
  color: #333;
  font-weight: 600;
}
.btn_submit:hover {
  color: #fff;
  background: #ff7200;
}
.btn_submit:disabled:hover {
  color: red;
  cursor: not-allowed;
  background: #fff;
}
.wrapper .register-link {
  font-size: 14.5px;
  text-align: center;
  margin: 20px 0 15px;
}

.register-link a {
  color: #ff7200;
  text-decoration: none;
  font-weight: 600;
}
.register-link a:hover {
  text-decoration: underline;
}
</style>
