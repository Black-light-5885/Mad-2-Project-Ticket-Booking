<template>
  <div>
    <div class="nav-fnav">
      <div class="left">
        <img src="./dummy/logo3.png" alt="" />
        <input
          v-model="searchKey"
          type="text"
          placeholder="Search for Movies, Theaters, shows etc.."
        />
      </div>

      <div class="right">
        <button>
          <router-link to="/login"><a>Logout</a></router-link>
        </button>
      </div>
    </div>
    <div class="nav-sec-nav">
      <div class="s-left">
        <router-link
          :to="{ name: 'User_Home', params: { uer_name: this.user_name } }"
          ><a>Home</a></router-link
        >

        <router-link
          :to="{
            name: 'User_Movies',
            params: { user_name: this.user_name },
          }"
          ><a>Movies</a></router-link
        >

        <router-link
          :to="{
            name: 'User_Theaters',
            params: { user_name: this.user_name },
          }"
          ><a>Theaters</a></router-link
        >
      </div>
      <div class="s-right">
        <router-link
          :to="{
            name: 'User_Bookings',
            params: { user_name: this.user_name },
          }"
        >
          <a>Bookings</a></router-link
        >
        <router-link
          :to="{
            name: 'User_Profile',
            params: { user_name: this.user_name },
          }"
        >
          <a>Profile</a></router-link
        >
      </div>
    </div>
    <div class="main" v-show="visible">
      <img src="./dummy/banner.jpg" alt="" />
    </div>
    <div class="new-movie">
      <h2>New Movies</h2>
    </div>
    <div class="container">
      <h1 v-if="searchMovie.length == 0">No reseult found!</h1>
      <div class="content">
        <div class="card" v-for="movie in searchMovie" :key="movie.id">
          <div class="card-content">
            <div class="image">
              <img :src="imgUrl(movie.picture)" alt="" />
            </div>
            <div class="name-movie">
              <span class="name">{{ movie.title }}</span>
              <span class="tag">{{ movie.tags }}</span>
              <span class="tag">{{ movie.lang }}</span>
            </div>
            <div class="rating">
              <h4>⭐ {{ movie.rating }}/5</h4>
              <span class="r-count">{{ movie.r_count }} Ratings</span>
            </div>
            <div class="button">
              <button class="delete" @click="movieTheater(movie)">
                Book Now
              </button>
              <button
                class="edit"
                :id="'movie-' + movie.id"
                @click="addRating(movie.id)"
              >
                Add Rating
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import Swal from "sweetalert2";
export default {
  props: {
    user_name: {
      type: String,
      required: true,
    },
  },
  data() {
    return {
      token: "",
      movies: [],
      imgbase: "data:image/*;charset=utf-8;base64,",
      user: {
        full_name: "",
        username: "",
        admin: null,
      },
      movie_name: "",
      movie_tag: "",
      img: {},
      add_rev: false,
      visible: true,
      searchKey: "",
    };
  },
  methods: {
    movieTheater(m) {
      this.$router.push({
        name: "Movie_Theaters",
        params: {
          user_name: this.user_name,
          movie_id: String(m.id),
          movie_name: String(m.title),
        },
      });
    },
    async addRating(movie_id) {
      const inputOptions = new Promise((resolve) => {
        setTimeout(() => {
          resolve({
            1: "Very-Bad",
            2: "Bad",
            3: "Average",
            4: "Good",
            5: "Excellent",
          });
        }, 500);
      });

      const { value: color } = await Swal.fire({
        title: "Select Review",
        input: "radio",
        inputOptions: inputOptions,
        showCancelButton: true,
        cancelButtonColor: "#d33",
        inputValidator: (value) => {
          if (!value) {
            return "You need to choose something!";
          }
        },
      });

      if (color) {
        Swal.fire({
          position: "top-end",
          icon: "success",
          title: "Review Added !",
          showConfirmButton: false,
          timer: 1500,
        });
        const data = { rating: color };
        fetch(`http://127.0.0.1:5000/app/api/movie/${movie_id}`, {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${this.token}`,
          },
          body: JSON.stringify(data),
        })
          .then((res) => {
            return res.json();
          })
          .then((data) => {
            if (data.msg === "Token has expired") {
              Swal.fire({
                icon: "error",
                title: "Session Exparired",
                text: "Login again",
              });
              this.$router.push("/login");
            }
            let b = document.getElementById("movie-" + movie_id);
            b.setAttribute("disabled", "true");
          });
      }
    },
    imgUrl(u) {
      return `${this.imgbase}${u}`;
    },

    getMovies() {
      console.log("called");
      fetch("http://127.0.0.1:5000/app/api/movie", {
        method: "GET",
        headers: {
          Authorization: `Bearer ${this.token}`,
        },
      })
        .then((res) => {
          return res.json();
        })
        .then((data) => {
          if (data.msg === "Token has expired") {
            Swal.fire({
              icon: "error",
              title: "Session Exparired",
              text: "Login again",
            });
            this.$router.push("/login");
          }
          console.log(data);
          this.movies = data.movies;
        });
    },
    updatePhoto(event) {
      this.img = event.target.files[0];
    },
    updateVisibleFalse() {
      this.visible = false;
    },
    updateVisibleTrue() {
      this.visible = true;
    },
    filterMovies() {
      let out = [];
      for (let m of this.movies) {
        if (m.title.toLowerCase().includes(this.searchKey.toLowerCase())) {
          out.push(m);
        } else if (
          m.lang.toLowerCase().includes(this.searchKey.toLowerCase())
        ) {
          out.push(m);
        }
      }
      return out;
    },
  },
  created() {
    const token = localStorage.getItem("token");
    if (token == null) {
      this.$router.push("/login");
    }
    this.token = token;
    this.getMovies();
  },
  computed: {
    searchMovie() {
      if (this.searchKey == "") {
        this.updateVisibleTrue();
        return this.movies;
      } else {
        this.updateVisibleFalse();
        return this.filterMovies();
      }
    },
  },
};
</script>

<style scoped>
* {
  margin: 0%;
  padding: 0%;
}

.nav-fnav {
  display: flex;
  justify-content: center;
  justify-content: space-around;
  padding: 15px;
  color: white;
  background-color: rgb(42, 42, 68);
}

.nav-fnav .left {
  display: flex;
  align-items: center;
}
.left img {
  width: 170px;
  height: 60px;
}
.left input {
  margin-inline: 11px;
  width: 320px;
  height: 33px;
  border: none;
  outline: none;
  text-align: center;
  border-radius: 3px;
}

.nav-fnav .right {
  display: flex;
  align-items: center;
}
.right a {
  margin-inline: 2px;
  font-size: 15px;
  text-decoration: none;
  color: white;
}
.left img {
  width: 170px;
  height: 60px;
}
.right button {
  margin-inline: 2px;
  width: 80px;
  height: 27px;
  border: none;
  border-radius: 5px;
  background-color: rgb(19, 131, 223);
  color: white;
  text-decoration: none;
  cursor: pointer;
  transition: 0.3s;
}
.right button:hover {
  background-color: #ff7200;
}
.nav-sec-nav {
  display: flex;
  justify-content: center;
  justify-content: space-around;
  padding: 10px;
  background-color: rgb(26, 26, 48);
  color: white;
}

.nav-sec-nav .s-left {
  display: flex;
}
.nav-sec-nav .s-right {
  display: flex;
  text-decoration: none;
}
.nav-sec-nav a:hover {
  color: brown;
  cursor: pointer;
  font-weight: bold;
  text-decoration: none;
}
.s-left a {
  margin-inline-start: 18px;
  text-decoration: none;
  color: white;
}

.s-right a {
  margin-inline-start: 18px;
  text-decoration: none;
  color: white;
}
.main img {
  width: 100%;
  margin-top: 10px;
}
.new-movie {
  padding: 10px;
  background-color: rgb(42, 42, 68);
}
.new-movie h2 {
  color: #fff;
}
.container {
  justify-content: center;
  align-items: center;
  min-height: 100vh;
}
.container h1 {
  justify-content: center;
  align-items: center;
  margin-top: 100px;
}
.card .image {
  width: 280px;
  height: 300px;
  border-radius: 5px;
}
.card .image img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  border-radius: 10px;
}
.card {
  background: rgb(42, 42, 68);
  border: 3px solid #0ef;
  border-radius: 10px;
  width: 310px;
  margin-top: 15px;
}
.content {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
}
.card .card-content {
  position: relative;
  display: flex;
  align-items: center;
  flex-direction: column;
  padding: 20px;
}

.card .name-movie {
  display: flex;
  align-items: center;
  flex-direction: column;
  margin-top: 10px;
  color: #fff;
}

.name-movie .name {
  font-size: 20px;
  font-weight: 600;
}

.name-movie .tag {
  font-size: 15px;
  font-weight: 400;
}
.card .rating {
  display: flex;
  align-items: center;
  margin-top: 18px;
  color: #fff;
}
.r-count {
  margin-left: 8px;
  color: #ff7200;
}
.card .button {
  display: flex;
  justify-content: space-around;
  width: 110%;
  margin-top: 20px;
}
.card .button button {
  background: #0ef;
  border: none;
  outline: none;
  color: #000;
  font-weight: 600;
  padding: 8px 22px;
  border-radius: 20px;
  font-size: 14px;
  cursor: pointer;
  transition: 0.3s;
}

.card .button button:hover {
  background: #fff;
}
.card .button button:disabled {
  background-color: green;
  cursor: not-allowed;
}
</style>
