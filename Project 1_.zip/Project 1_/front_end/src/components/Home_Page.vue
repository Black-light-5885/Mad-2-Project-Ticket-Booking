<template>
  <div>
    <div class="navbar_own">
      <div class="icon">
        <h2 class="logo">Book <span class="no-fill">For</span>You</h2>
      </div>
      <div class="menu">
        <ul class="menu-content">
          <li class="menu-content-item">
            <a href="/" id="Home"> Home</a>
          </li>
          <li class="menu-content-item">
            <a href="/login" id="Blogs"> Login</a>
          </li>
          <li class="menu-content-item" id="rigister">
            <a href="/register" id="Profile"> Register</a>
          </li>
        </ul>
      </div>
    </div>
    <div class="main_1">
      <div class="content_home">
        <h1 class="home_title">
          Modern Application<br />
          <span> Development - II</span><br />Project - <span>May-2023</span
          ><br />
        </h1>
        <br />
        <button class="join_us"><a href="/login"> Explore more</a></button>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "HelloWorld",
  props: {
    msg: String,
  },
};
</script>
<style scoped>
* {
  margin: 0%;
  padding: 0%;
}

.navbar_own {
  width: 100%;
  height: 95px;
  margin: auto;
  background-color: rgb(31, 31, 31);
}
.icon {
  width: 200px;
  float: left;
  height: 70px;
}
.logo {
  color: #ff7200;
  font-size: 35px;
  font-family: "Franklin Gothic Medium", "Arial Narrow", Arial, sans-serif;
  padding-left: 10px;
  float: left;
  padding-top: 10px;
}
.logo .no-fill {
  font-style: italic;
  color: transparent;
  -webkit-text-stroke: 0.5px #ffffff;
  font-family: Verdana, Geneva, Tahoma, sans-serif;
}

.menu {
  width: 400px;
  float: left;
  height: 70px;
}
.menu-content {
  float: left;
  display: flex;
  justify-content: center;
  align-items: center;
}
.menu-content-item {
  list-style: none;
  margin-left: 62px;
  margin-top: 27px;
  font-size: 20px;
}

.menu-content-item a {
  text-decoration: none;
  color: #fff;
  font-family: "Trebuchet MS", "Lucida Sans Unicode", "Lucida Grande",
    "Lucida Sans", Arial, sans-serif;
  font-weight: bold;
  transition: 0.1s ease-in-out;
}
.menu-content-item a:hover {
  color: #ff7200;
}
.menu-content-item #Logout {
  position: fixed;
  top: 27px;
  right: 50px;
  z-index: 10;
}
.search {
  width: 330px;
  float: left;
  margin-left: 270px;
}
.srch {
  font-family: "Times New Roman", Times, serif;
  width: 200px;
  height: 40px;
  background: transparent;
  border: 1px solid #ff7200;
  margin-top: 20px;
  color: #fff;
  border-right: none;
  font-size: 16px;
  float: left;
  padding: 10px;
  border-bottom-left-radius: 5px;
  border-top-left-radius: 5px;
}
.btn_nav_search {
  width: 100px;
  height: 40px;
  background: #ff7200;
  border: 2px solid #ff7200;
  margin-top: 20px;
  color: #fff;
  font-size: 15px;
  border-bottom-right-radius: 5px;
}
.btn_nav_search:focus {
  outline: none;
}

.srch:focus {
  outline: none;
}

#rigister {
  margin-left: 55rem;
  z-index: 1rem;
}

.main_1 {
  width: 100%;
  background: linear-gradient(
      to top,
      rgba(0, 0, 0, 0.5) 50%,
      rgba(0, 0, 0, 0.5) 50%
    ),
    url(./dummy/login.jpg);
  background-position: center;
  background-size: cover;
  height: 100vh;
  margin-top: 0;
  position: fixed;
}

.content_home {
  width: 1100px;
  height: auto;
  margin: auto;
  color: #fff;
  position: relative;
}
.content_home .para {
  padding-left: 20px;
  padding-bottom: 25px;
  font-family: Arial;
  letter-spacing: 1.2px;
  line-height: 30px;
}
.content_home .home_title {
  font-family: "Times New Roman";
  font-size: 50px;
  padding-left: 20px;
  margin-top: 9%;
  letter-spacing: 2px;
}

.content_home .join_us {
  width: 160px;
  height: 40px;
  background: #ff7200;
  border: none;
  margin-bottom: 10px;
  margin-left: 20px;
  font-size: 18px;
  border-radius: 10px;
  cursor: pointer;
  transition: 0.3s ease;
}
.content_home .join_us a {
  text-decoration: none;
  color: #000;
  transition: 0.3s ease;
}
.join_us:hover {
  background-color: #fff;
}
.content_home span {
  color: #ff7200;
  font-size: 60px;
}
</style>
