<template>
  <div>
    <div class="nav-fnav">
      <div class="left">
        <img src="./dummy/logo3.png" alt="" />
        <input
          type="text"
          placeholder="Search for Movies, Theaters, shows etc.."
        />
      </div>

      <div class="right">
        <button>
          <router-link to="/login"><a>Logout</a></router-link>
        </button>
      </div>
    </div>
    <div class="nav-sec-nav">
      <div class="s-left">
        <router-link
          :to="{ name: 'User_Home', params: { uer_name: this.user_name } }"
          ><a>Home</a></router-link
        >

        <router-link
          :to="{
            name: 'User_Movies',
            params: { user_name: this.user_name },
          }"
          ><a>Movies</a></router-link
        >

        <router-link
          :to="{
            name: 'User_Theaters',
            params: { user_name: this.user_name },
          }"
          ><a>Theaters</a></router-link
        >
      </div>
      <div class="s-right">
        <router-link
          :to="{
            name: 'User_Bookings',
            params: { user_name: this.user_name },
          }"
        >
          <a>Bookings</a></router-link
        >
        <router-link
          :to="{
            name: 'User_Profile',
            params: { user_name: this.user_name },
          }"
        >
          <a>Profile</a></router-link
        >
      </div>
    </div>
    <div class="Headline">
      <h2>Booking Page</h2>
    </div>
    <div class="container">
      <div class="content">
        <div class="card">
          <div class="card-content">
            <div class="theater-name">
              <h2 class="name">{{ show.name }}</h2>
            </div>
            <div class="capacity">
              <h4>
                Place : <span class="location">{{ show.location }}</span>
              </h4>
            </div>
            <div class="capacity">
              <h4>
                Date : <span class="location">{{ show.date }}</span>
              </h4>
              <h4>
                Time : <span class="location">{{ show.time }}</span>
              </h4>
            </div>
            <div class="capacity">
              <h4><span>Movie :</span> {{ show.movie }}</h4>
              <h4><span>Theater :</span> {{ show.theater }}</h4>
            </div>
            <div class="capacity">
              <h4>Price : ₹{{ show.price }}</h4>
              <h4>Available Seats : {{ show.available }}</h4>
            </div>
            <div class="error" v-if="error">
              <p>{{ error_msg }}</p>
            </div>
            <div class="capacity">
              <input
                type="number"
                placeholder="Enter Number of Tickets"
                v-model="ticket_count"
              />
            </div>
            <div class="capacity">
              <h3>Total : {{ total }}</h3>
            </div>
            <div class="button">
              <button class="edit" :disabled="error" @click="bookTicket">
                Book Ticket
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import Swal from "sweetalert2";
export default {
  props: {
    user_name: {
      type: String,
      required: true,
    },
    s_id: {
      type: String,
      required: true,
    },
  },
  data() {
    return {
      token: "",
      user: {
        full_name: "",
        username: "",
        admin: null,
      },
      show: {},
      ticket_count: null,
      total: 0,
      error: false,
      error_msg: "",
    };
  },
  methods: {
    bookTicket() {
      const data = {
        user: this.user_name,
        theater: this.show.theater,
        show: this.show.id,
        movie: this.show.movie,
        count: this.ticket_count,
        total: this.total,
      };
      Swal.fire({
        title: "Payment",
        text: "Scan the QR to complete the Payment",
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/5/5b/Qrcode_wikipedia.jpg?20110112164952",
        imageWidth: 400,
        imageHeight: 400,
        imageAlt: "Custom image",
        showCancelButton: true,
        confirmButtonText: "Pay",
      }).then((result) => {
        if (result.isConfirmed) {
          fetch("http://127.0.0.1:5000/app/api/bookings", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${this.token}`,
            },
            body: JSON.stringify(data),
          })
            .then((res) => {
              return res.json();
            })
            .then((data) => {
              if (data.msg === "Token has expired") {
                Swal.fire({
                  icon: "error",
                  title: "Session Exparired",
                  text: "Login again",
                });
                this.$router.push("/login");
              }
              Swal.fire({
                position: "top-end",
                icon: "success",
                title: " Booking successful!",
                showConfirmButton: false,
                timer: 1500,
              });
              this.$router.push({
                name: "User_Bookings",
                params: { user_name: this.user_name },
              });
            })
            .catch((error) => {
              if (error.message.startsWith("Token")) {
                alert("Session Expaired. Please Login again!");
                this.$route.put("/login");
              } else {
                console.log(error);
              }
            });
        }
      });
    },
    getShows() {
      fetch(`http://127.0.0.1:5000/app/api/show/${this.s_id}`, {
        method: "GET",
        headers: {
          Authorization: `Bearer ${this.token}`,
        },
      })
        .then((res) => {
          return res.json();
        })
        .then((data) => {
          if (data.msg === "Token has expired") {
            Swal.fire({
              icon: "error",
              title: "Session Exparired",
              text: "Login again",
            });
            this.$router.push("/login");
          }
          this.show = data.shows;
        });
    },
  },
  created() {
    const token = localStorage.getItem("token");
    if (token == null) {
      this.$router.push("/login");
    }
    this.token = token;
    this.getShows();
  },
  watch: {
    ticket_count(new_v) {
      new_v = Number(new_v);
      if (new_v > Number(this.show.available)) {
        this.error = true;
        this.error_msg = "Number of Tickets are more than available!";
        this.total = 0;
      } else if (new_v < 1) {
        this.error = true;
        this.error_msg = "Number of Tickets can't be 0 or Negative";
        this.total = 0;
      } else if (!Number.isNaN(new_v) && !Number.isInteger(new_v)) {
        this.error = true;
        this.error_msg = "Number of Tickets can't be Float values";
        this.total = 0;
      } else {
        this.error = false;
        this.total = Number(this.show.price) * new_v;
      }
    },
  },
};
</script>

<style scoped>
* {
  margin: 0%;
  padding: 0%;
}

.nav-fnav {
  display: flex;
  justify-content: center;
  justify-content: space-around;
  padding: 15px;
  color: white;
  background-color: rgb(42, 42, 68);
}

.nav-fnav .left {
  display: flex;
  align-items: center;
}

.left input {
  margin-inline: 11px;
  width: 320px;
  height: 33px;
  border: none;
  outline: none;
  text-align: center;
  border-radius: 3px;
}

.nav-fnav .right {
  display: flex;
  align-items: center;
}
.right a {
  margin-inline: 2px;
  font-size: 15px;
  text-decoration: none;
  color: white;
}
.left img {
  width: 170px;
  height: 60px;
}
.right button {
  margin-inline: 2px;
  width: 80px;
  height: 27px;
  border: none;
  border-radius: 5px;
  background-color: rgb(19, 131, 223);
  color: white;
  text-decoration: none;
  cursor: pointer;
  transition: 0.3s;
}
.right button:hover {
  background-color: #ff7200;
}
.nav-sec-nav {
  display: flex;
  justify-content: center;
  justify-content: space-around;
  padding: 10px;
  background-color: rgb(26, 26, 48);
  color: white;
}

.nav-sec-nav .s-left {
  display: flex;
}
.nav-sec-nav .s-right {
  display: flex;
  text-decoration: none;
}
.nav-sec-nav a:hover {
  color: brown;
  cursor: pointer;
  font-weight: bold;
  text-decoration: none;
}
.s-left a {
  margin-inline-start: 18px;
  text-decoration: none;
  color: white;
}

.s-right a {
  margin-inline-start: 18px;
  text-decoration: none;
  color: white;
}
.container {
  justify-content: center;
  align-items: center;
  min-height: 100vh;
}
.card {
  background: rgb(42, 42, 68);
  border: 3px solid #0ef;
  border-radius: 30px;
  width: 600px;
  height: 480px;
  margin-top: 15px;
}
.content {
  display: flex;
  justify-content: center;
}
.card .card-content {
  position: relative;
  display: flex;
  align-items: center;
  flex-direction: column;
  padding: 10px;
}
.card .theater-name {
  display: flex;
  align-items: center;
  flex-direction: column;
  margin-top: 10px;
  color: #fff;
}
.theater-name .name {
  font-size: 40px;
  font-weight: 600;
}

.theater-name .location {
  font-size: 15px;
  font-weight: 400;
}
.card .capacity {
  display: flex;
  justify-content: space-between;
  margin-top: 18px;
  color: #fff;
}
.card .capacity span {
  color: #ff7200;
}
.card .capacity h4 {
  padding: 8px 40px;
  border-radius: 20px;
}
.card .error {
  display: flex;
  justify-content: space-between;
  margin-top: 18px;
  color: #f54545;
}

.card .capacity input {
  width: 100%;
  height: 100%;
  background: #ff7200;
  border: none;
  outline: none;
  border: 2px solid rgba(255, 255, 255, 0.2);
  border-radius: 10px;
  font-size: 16px;
  color: rgba(255, 255, 255, 0.945);
  padding: 10px 15px 10px 10px;
}

.card .capacity input::placeholder {
  color: #fff;
  text-align: center;
  font-size: 13px;
}
.card .button {
  display: flex;
  justify-content: space-around;
  width: 110%;
  margin-top: 20px;
}
.card .button button {
  background: #0ef;
  border: none;
  outline: none;
  color: #000;
  font-weight: 600;
  padding: 10px 25px;
  border-radius: 20px;
  font-size: 14px;
  cursor: pointer;
  transition: 0.3s;
}
.card .button button:hover {
  background: #fff;
}
.card .button button:disabled {
  background: #f08383;
  cursor: not-allowed;
}
</style>
