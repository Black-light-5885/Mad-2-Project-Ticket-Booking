<template>
  <div>
    <div class="nav-fnav">
      <div class="left">
        <img src="./dummy/logo3.png" alt="" />
        <input
          v-model="searchKey"
          type="text"
          placeholder="Search for Movies, Theaters, shows etc.."
        />
      </div>

      <div class="right">
        <button>
          <router-link to="/login"><a>Logout</a></router-link>
        </button>
      </div>
    </div>
    <div class="nav-sec-nav">
      <div class="s-left">
        <router-link
          :to="{ name: 'User_Home', params: { uer_name: this.user_name } }"
          ><a>Home</a></router-link
        >

        <router-link
          :to="{
            name: 'User_Movies',
            params: { user_name: this.user_name },
          }"
          ><a>Movies</a></router-link
        >

        <router-link
          :to="{
            name: 'User_Theaters',
            params: { user_name: this.user_name },
          }"
          ><a>Theaters</a></router-link
        >
      </div>
      <div class="s-right">
        <router-link
          :to="{
            name: 'User_Bookings',
            params: { user_name: this.user_name },
          }"
        >
          <a>Bookings</a></router-link
        >
        <router-link
          :to="{
            name: 'User_Profile',
            params: { user_name: this.user_name },
          }"
        >
          <a>Profile</a></router-link
        >
      </div>
    </div>
    <div class="Headline">
      <h2>Booking History</h2>
    </div>
    <div class="container">
      <h1 v-if="bookings.length == 0">You haven't Booked anything.</h1>
      <h1 v-if="searchBooking.length == 0">No result found</h1>
      <div class="content">
        <div
          class="card"
          v-for="booking in searchBooking"
          :key="booking.booking_id"
        >
          <div class="card-content">
            <div class="theater-name">
              <h2 class="name">{{ booking.show_name }}</h2>
            </div>
            <div class="capacity">
              <h4>
                Place : <span class="location">{{ booking.location }}</span>
              </h4>
            </div>
            <div class="capacity">
              <h4>
                Time : <span class="location">{{ booking.time }}</span>
              </h4>
            </div>
            <div class="capacity">
              <h4><span>Movie :</span> {{ booking.movie }}</h4>
              <h4><span>Theater :</span> {{ booking.theater }}</h4>
            </div>
            <div class="capacity">
              <h4>Price : ₹{{ booking.price }}</h4>
              <h4>Number of Booking : {{ booking.count }}</h4>
            </div>

            <div class="capacity">
              <h3>Total : {{ booking.total }}</h3>
            </div>
            <div class="button">
              <button class="edit" @click="cancelBooking(booking)">
                Cancel Ticket
              </button>
              <button class="edit" @click="downloadTicket(booking)">
                Download Ticket
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import Swal from "sweetalert2";
import jsPDF from "jspdf";
export default {
  props: {
    user_name: {
      type: String,
      required: true,
    },
  },
  data() {
    return {
      token: "",
      user: {
        full_name: "",
        username: "",
        admin: null,
      },
      bookings: [],
      searchKey: "",
    };
  },
  methods: {
    downloadTicket(booking) {
      var t = new jsPDF();
      t.text("Ticket ", 100, 10);
      t.text("Show Name :", 30, 25);
      t.text(booking.show_name, 100, 25);
      t.text("Date :", 30, 40);
      t.text(booking.date, 55, 40);
      t.text("Time :", 90, 40);
      t.text(booking.time, 110, 40);
      t.text("Movie Name :", 30, 60);
      t.text(booking.movie, 100, 60);
      t.text("Theater Name :", 30, 80);
      t.text(booking.theater, 100, 80);
      t.text("Place :", 30, 100);
      t.text(booking.location, 100, 100);
      t.text("Ticket Count :", 30, 120);
      t.text(String(booking.count), 100, 120);
      t.text("Total :", 30, 140);
      t.text(String(booking.total), 100, 140);
      t.text("Thanks for using BookForYou!", 60, 175);
      t.save("ticket.pdf");
    },
    cancelBooking(b) {
      Swal.fire({
        title: "Are you sure? Wants to cancel this Ticket",
        text: "You won't be able to revert this!",
        icon: "warning",
        showCancelButton: true,
        confirmButtonColor: "#3085d6",
        cancelButtonColor: "#d33",
        confirmButtonText: "Yes, Cancel it!",
        cancelButtonText: "Back",
      }).then((result) => {
        if (result.isConfirmed) {
          const c = this.bookings.indexOf(b);
          const b_id = String(b.id);
          console.log(b_id, b.id);
          this.bookings.splice(c, 1);
          fetch(`http://127.0.0.1:5000/app/api/booking/${b_id}`, {
            method: "DELETE",
            headers: {
              Authorization: `Bearer ${this.token}`,
            },
          })
            .then((res) => {
              return res.json();
            })
            .then((data) => {
              if (data == "Deleted successfully") {
                Swal.fire("Canceled!", "Ticket has been Canceled.", "success");
              } else {
                Swal.fire("Something is wrong!", "Not deleted.", "failed");
              }
            });
        }
      });
    },
    getBookings() {
      fetch(`http://127.0.0.1:5000/app/api/bookings/${this.user_name}`, {
        method: "GET",
        headers: {
          Authorization: `Bearer ${this.token}`,
        },
      })
        .then((res) => {
          return res.json();
        })
        .then((data) => {
          if (data.msg === "Token has expired") {
            Swal.fire({
              icon: "error",
              title: "Session Exparired",
              text: "Login again",
            });
            this.$router.push("/login");
          }
          this.bookings = data.bookings;
        });
    },
    filterBooking() {
      let out = [];
      for (let b of this.bookings) {
        if (b.show_name.toLowerCase().includes(this.searchKey.toLowerCase())) {
          out.push(b);
        } else if (
          b.location.toLowerCase().includes(this.searchKey.toLowerCase())
        ) {
          out.push(b);
        } else if (
          b.movie.toLowerCase().includes(this.searchKey.toLowerCase())
        ) {
          out.push(b);
        } else if (
          b.theater.toLowerCase().includes(this.searchKey.toLowerCase())
        ) {
          out.push(b);
        }
      }
      return out;
    },
  },
  created() {
    const token = localStorage.getItem("token");
    if (token == null) {
      this.$router.push("/login");
    }
    this.token = token;
    this.getBookings();
  },
  computed: {
    searchBooking() {
      if (this.searchKey == "") {
        return this.bookings;
      } else {
        return this.filterBooking();
      }
    },
  },
  watch: {
    ticket_count(new_v) {
      this.total = Number(this.show.price) * new_v;
      if (new_v > Number(this.show.available)) {
        this.error = true;
        this.error_msg = "Number of Tickets are more than available!";
      } else {
        this.error = false;
      }
    },
  },
};
</script>

<style scoped>
* {
  margin: 0%;
  padding: 0%;
}

.nav-fnav {
  display: flex;
  justify-content: center;
  justify-content: space-around;
  padding: 15px;
  color: white;
  background-color: rgb(42, 42, 68);
}

.nav-fnav .left {
  display: flex;
  align-items: center;
}

.left input {
  margin-inline: 11px;
  width: 320px;
  height: 33px;
  border: none;
  outline: none;
  text-align: center;
  border-radius: 3px;
}

.nav-fnav .right {
  display: flex;
  align-items: center;
}
.right a {
  margin-inline: 2px;
  font-size: 15px;
  text-decoration: none;
  color: white;
}
.left img {
  width: 170px;
  height: 60px;
}
.right button {
  margin-inline: 2px;
  width: 80px;
  height: 27px;
  border: none;
  border-radius: 5px;
  background-color: rgb(19, 131, 223);
  color: white;
  text-decoration: none;
  cursor: pointer;
  transition: 0.3s;
}
.right button:hover {
  background-color: #ff7200;
}
.nav-sec-nav {
  display: flex;
  justify-content: center;
  justify-content: space-around;
  padding: 10px;
  background-color: rgb(26, 26, 48);
  color: white;
}

.nav-sec-nav .s-left {
  display: flex;
}
.nav-sec-nav .s-right {
  display: flex;
  text-decoration: none;
}
.nav-sec-nav a:hover {
  color: brown;
  cursor: pointer;
  font-weight: bold;
  text-decoration: none;
}
.s-left a {
  margin-inline-start: 18px;
  text-decoration: none;
  color: white;
}

.s-right a {
  margin-inline-start: 18px;
  text-decoration: none;
  color: white;
}
.Headline {
  padding: 10px;
  background-color: #3ca872af;
}
.Headline h2 {
  color: rgb(42, 42, 68);
}
.container {
  justify-content: center;
  align-items: center;
  min-height: 100vh;
}
.container h1 {
  justify-content: center;
  align-items: center;
  margin-top: 100px;
}
.card {
  background: rgb(42, 42, 68);
  border: 3px solid #0ef;
  border-radius: 30px;
  width: 600px;
  height: 400px;
  margin-top: 15px;
}
.content {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
}
.card .card-content {
  position: relative;
  display: flex;
  align-items: center;
  flex-direction: column;
  padding: 10px;
}
.card .theater-name {
  display: flex;
  align-items: center;
  flex-direction: column;
  margin-top: 10px;
  color: #fff;
}
.theater-name .name {
  font-size: 40px;
  font-weight: 600;
}

.theater-name .location {
  font-size: 15px;
  font-weight: 400;
}
.card .capacity {
  display: flex;
  justify-content: space-between;
  margin-top: 18px;
  color: #fff;
}
.card .capacity span {
  color: #ff7200;
}
.card .capacity h4 {
  padding: 8px 40px;
  border-radius: 20px;
}
.card .error {
  display: flex;
  justify-content: space-between;
  margin-top: 18px;
  color: #f54545;
}

.card .capacity input {
  width: 100%;
  height: 100%;
  background: #ff7200;
  border: none;
  outline: none;
  border: 2px solid rgba(255, 255, 255, 0.2);
  border-radius: 10px;
  font-size: 16px;
  color: rgba(255, 255, 255, 0.945);
  padding: 10px 15px 10px 10px;
}

.card .capacity input::placeholder {
  color: #fff;
  text-align: center;
  font-size: 13px;
}
.card .button {
  display: flex;
  justify-content: space-around;
  width: 110%;
  margin-top: 20px;
}
.card .button button {
  background: #0ef;
  border: none;
  outline: none;
  color: #000;
  font-weight: 600;
  padding: 10px 25px;
  border-radius: 20px;
  font-size: 14px;
  cursor: pointer;
  transition: 0.3s;
}
.card .button button:hover {
  background: #fff;
}
.card .button button:disabled {
  background: #f08383;
  cursor: not-allowed;
}
</style>
