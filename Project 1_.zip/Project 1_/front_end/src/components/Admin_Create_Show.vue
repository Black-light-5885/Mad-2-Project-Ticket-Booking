<template>
  <div>
    <div class="nav-fnav">
      <div class="left">
        <img src="./dummy/logo3.png" alt="" />
        <input
          type="text"
          placeholder="Search for Movies, Theaters, shows etc.."
        />
      </div>

      <div class="right">
        <button>
          <router-link to="/login"><a>Logout</a></router-link>
        </button>
      </div>
    </div>

    <div class="nav-sec-nav">
      <div class="s-left">
        <router-link
          :to="{ name: 'Admin_Home', params: { uer_name: this.user_name } }"
          ><a>Home</a></router-link
        >

        <router-link
          :to="{
            name: 'Admin_Movies',
            params: { user_name: this.user_name },
          }"
          ><a>Movies</a></router-link
        >

        <router-link
          :to="{
            name: 'Admin_Theaters',
            params: { user_name: this.user_name },
          }"
          ><a>Theaters</a></router-link
        >
        <router-link
          :to="{
            name: 'Admin_Shows',
            params: { user_name: this.user_name },
          }"
          ><a>Shows</a></router-link
        >
      </div>
      <div class="s-right">
        <router-link
          :to="{
            name: 'Create_Movie',
            params: { user_name: this.user_name },
          }"
          ><a>Add Movie</a></router-link
        >
        <router-link
          :to="{
            name: 'Create_Theater',
            params: { user_name: this.user_name },
          }"
          ><a>Add Theater</a></router-link
        >
        <router-link
          :to="{
            name: 'Create_Show',
            params: { user_name: this.user_name },
          }"
          ><a>Add Show</a></router-link
        >
        <router-link
          :to="{
            name: 'User_Profile',
            params: { user_name: this.user_name },
          }"
        >
          <a>Profile</a></router-link
        >
      </div>
    </div>
    <div class="main">
      <h1>Create New Show</h1>
    </div>
    <div class="container">
      <div class="create-movie">
        <h2>New Show</h2>
        <form @submit.prevent="CreateShow">
          <div class="error" v-if="error">
            <p>{{ Error_msg }}</p>
          </div>
          <div class="input">
            <input
              type="text"
              id="theater_name"
              placeholder="Enter Theater Name Here"
              v-model="theater_name"
            />
            <div class="options" v-show="visible">
              <ul class="list1">
                <li
                  class="list-items"
                  :key="index"
                  v-for="(match, index) in matches"
                  @click="selectItem(index)"
                  v-text="match"
                ></li>
              </ul>
            </div>
          </div>
          <div class="input">
            <input
              type="text"
              id="movie_name"
              placeholder="Enter Movie Name"
              v-model="movie_name"
            />
            <div class="options" v-show="visible">
              <ul class="list1">
                <li
                  class="list-items"
                  :key="index"
                  v-for="(match, index) in matches2"
                  @click="selectItem2(index)"
                  v-text="match"
                ></li>
              </ul>
            </div>
          </div>

          <input
            type="text"
            @click="togleVisible"
            placeholder="Enter Show Name"
            v-model="show_name"
          />
          <input type="number" placeholder="Price" max="300" v-model="price" />
          <div class="date-show">
            <label for="date">Show Date :</label>
            <input type="date" v-model="date" />
          </div>
          <div class="date-show-time">
            <label>Show Time :</label>
            <select v-model="show_time" class="form-select">
              <option selected>Select Time</option>
              <option value="08 AM - 10.45 AM">08 AM - 10.45 AM</option>
              <option value="11 AM - 12.45 PM">11 AM - 12.45 PM</option>
              <option value="01 PM - 03.45 AM">01 PM - 03.45 PM</option>
              <option value="05 PM - 07.45 PM">05 PM - 07.45 PM</option>
              <option value="09 AM - 11.45 PM">09 AM - 11.45 PM</option>
            </select>
          </div>
          <button class="btn_submit">Create Show</button>
        </form>
      </div>
    </div>
  </div>
</template>

<script>
import Swal from "sweetalert2";
export default {
  props: {
    user_name: {
      type: String,
      required: true,
    },
  },
  data() {
    return {
      token: "",
      user: {
        full_name: "",
        username: "",
        admin: null,
      },
      theater_name: "",
      movie_name: "",
      show_name: "",
      show_time: "",
      price: "",
      movie_list: [],
      theater_list: [],
      visible: false,
      error: false,
      date: "",
      Error_msg: "",
    };
  },

  methods: {
    togleVisible() {
      this.visible = !this.visible;
    },
    selectItem(i) {
      this.theater_name = this.matches[i];
    },
    selectItem2(i) {
      this.movie_name = this.matches2[i];
    },
    getMovies() {
      fetch("http://127.0.0.1:5000/app/api/movie", {
        method: "GET",
        headers: {
          Authorization: `Bearer ${this.token}`,
        },
      })
        .then((res) => {
          return res.json();
        })
        .then((data) => {
          for (let movie of data.movies) {
            this.movie_list.push(movie.title);
          }
        });
    },
    getTheater() {
      fetch("http://127.0.0.1:5000/app/api/theater", {
        method: "GET",
        headers: {
          Authorization: `Bearer ${this.token}`,
        },
      })
        .then((res) => {
          return res.json();
        })
        .then((data) => {
          for (let theater of data.theaters) {
            this.theater_list.push(theater.name);
          }
        });
    },
    getUser_details(token_) {
      fetch(`http://127.0.0.1:5000/app/api/user/${this.user_name}`, {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token_}`,
        },
      })
        .then((res) => {
          return res.json();
        })
        .then((data) => {
          this.user.full_name = data.full_name;
          this.user.admin = data.admin;
          if (data.msg === "Token has expired") {
            Swal.fire({
              icon: "error",
              title: "Session Exparired",
              text: "Login again",
            });
            this.$router.push("/login");
          }
        });
    },
    valiDate() {
      if (
        this.theater_name != "" &&
        this.movie_name != "" &&
        this.show_time != "" &&
        this.show_name != ""
      ) {
        return true;
      } else {
        this.error = true;
        this.Error_msg = "Fille The blanks to create a new show!";
        return false;
      }
    },
    CreateShow() {
      const data = {
        theater: this.theater_name,
        movie: this.movie_name,
        show_name: this.show_name,
        price: this.price,
        show_time: this.show_time,
        date: this.date,
      };
      if (this.valiDate()) {
        fetch("http://127.0.0.1:5000/app/api/show", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${this.token}`,
          },
          body: JSON.stringify(data),
        })
          .then((res) => {
            return res.json();
          })
          .then((data) => {
            if (data.msg === "Token has expired") {
              alert("Session Expaired. Login again");
              this.$router.push("/login");
            }
            Swal.fire({
              position: "top-end",
              icon: "success",
              title: "Your work has been saved",
              showConfirmButton: false,
              timer: 1500,
            });
            this.$router.push({
              name: "Admin_Shows",
              params: { user_name: this.user_name },
            });
          })
          .catch((error) => {
            if (error.message.startsWith("Token")) {
              alert("Session Expaired. Please Login again!");
              Swal.fire({
                icon: "error",
                title: "Session Exparired",
                text: "Login again",
              });
            } else {
              console.log(error);
            }
          });
      }
    },
    displayNames(value) {
      let input = document.getElementById("theater_name");
      input.value = value;
    },
    removeElement() {
      let items = document.querySelectorAll(".list-item");
      items.forEach((item) => {
        item.remove();
      });
    },
  },
  created() {
    const token = localStorage.getItem("token");
    if (token == null) {
      this.$router.push("/login");
    }
    this.token = token;
    this.getUser_details(token);
    this.getMovies();
    this.getTheater();
  },
  computed: {
    matches() {
      if (this.theater_name == "") {
        return [];
      }
      return this.theater_list.filter((item) =>
        item.toLocaleLowerCase().includes(this.theater_name.toLocaleLowerCase())
      );
    },
    matches2() {
      if (this.movie_name == "") {
        return [];
      }
      return this.movie_list.filter((item) =>
        item.toLocaleLowerCase().includes(this.movie_name.toLocaleLowerCase())
      );
    },
  },
  watch: {
    theater_name(new_value) {
      if (new_value != "") {
        this.visible = true;
        if (!this.theater_list.includes(new_value)) {
          this.error = true;
          this.Error_msg = "Not a valid Theater Name!";
        } else {
          this.error = false;
        }
      }
    },
    movie_name(new_value) {
      if (new_value != "") {
        this.visible = true;
        if (!this.movie_list.includes(new_value)) {
          this.error = true;
          this.Error_msg = "Not a valid Movie Name!";
        } else {
          this.error = false;
        }
      }
    },
    // let sortedTheater = this.theater_list.sort();
    // this.removeElement();
    // for (let i of sortedTheater) {
    //   if (
    //     i.toLocaleLowerCase().startsWith(new_value.toLocaleLowerCase()) &&
    //     new_value != ""
    //   ) {
    //     let listItem = document.createElement("li");
    //     listItem.classList.add("list-item");
    //     listItem.style.cursor = "pointer";
    //     listItem.setAttribute("click", "displayNames('" + i + "')");
    //     let word = "<b>" + i.substring(0, new_value.length) + "</b>";
    //     word += i.substring(new_value.length);
    //     listItem.innerHTML = word;
    //     document.querySelector(".list1").appendChild(listItem);
    //   }
    // }
    // },
    // movie_name(new_value) {
    //   let sortedMovie = this.movie_list.sort();
    //   this.removeElement();
    //   for (let i of sortedMovie) {
    //     if (
    //       i.toLocaleLowerCase().startsWith(new_value.toLocaleLowerCase()) &&
    //       new_value != ""
    //     ) {
    //       let listItem = document.createElement("li");
    //       listItem.classList.add("list-item");
    //       listItem.style.cursor = "pointer";
    //       listItem.setAttribute("onclick", "$displayNames('" + i + "')}");
    //       let word = "<b>" + i.substring(0, new_value.length) + "</b>";
    //       word += i.substring(new_value.length);
    //       listItem.innerHTML = word;
    //       document.querySelector(".list2").appendChild(listItem);
    //     }
    //   }
    // },
  },
};
</script>

<style scoped>
* {
  margin: 0%;
  padding: 0%;
}

.nav-fnav {
  display: flex;
  justify-content: center;
  justify-content: space-around;
  padding: 15px;
  color: white;
  background-color: rgb(42, 42, 68);
}

.nav-fnav .left {
  display: flex;
  align-items: center;
}

.left input {
  margin-inline: 11px;
  width: 320px;
  height: 33px;
  border: none;
  outline: none;
  text-align: center;
  border-radius: 3px;
}

.nav-fnav .right {
  display: flex;
  align-items: center;
}
.right a {
  margin-inline: 2px;
  font-size: 15px;
  text-decoration: none;
  color: white;
}
.left img {
  width: 170px;
  height: 60px;
}
.right button {
  margin-inline: 2px;
  width: 80px;
  height: 27px;
  border: none;
  border-radius: 5px;
  background-color: rgb(19, 131, 223);
  color: white;
  text-decoration: none;
  cursor: pointer;
  transition: 0.3s;
}
.right button:hover {
  background-color: #ff7200;
}
.nav-sec-nav {
  display: flex;
  justify-content: center;
  justify-content: space-around;
  padding: 10px;
  background-color: rgb(26, 26, 48);
  color: white;
}

.nav-sec-nav .s-left {
  display: flex;
}
.nav-sec-nav .s-right {
  display: flex;
  text-decoration: none;
}
.nav-sec-nav a:hover {
  color: brown;
  cursor: pointer;
  font-weight: bold;
  text-decoration: none;
}
.s-left a {
  margin-inline-start: 18px;
  text-decoration: none;
  color: white;
}

.s-right a {
  margin-inline-start: 18px;
  text-decoration: none;
  color: white;
}
.main img {
  width: 100%;
  margin-top: 10px;
}
.main h1 {
  padding: 22px;
}
.container {
  display: flex;
  justify-content: center;
  align-items: center;
}
.create-movie {
  margin-top: 20px;
  width: 520px;
  background: gray;
  border: 2px solid rgba(153, 153, 153, 0.2);
  backdrop-filter: blur(20px);
  box-shadow: 0 0 10 rgba(0, 0, 0, 0.2);
  color: #ffff;
  border-radius: 10px;
  padding: 30px 40px;
}
.create-movie .error {
  color: red;
}
.create-movie input {
  width: 240px;
  height: 35px;
  margin-left: 25px;
  background: transparent;
  border-bottom: 1px solid #ff7200;
  border-top: none;
  border-right: none;
  border-left: none;
  color: rgb(0, 0, 0);
  font-size: 15px;
  letter-spacing: 1px;
  margin-top: 30px;
  font-family: sans-serif;
}
.create-movie input:focus {
  outline: none;
}
::placeholder {
  color: rgb(0, 0, 0);
  font-family: Arial, Helvetica, sans-serif;
}

.btn_submit {
  width: 240px;
  height: 40px;
  background: #ff7200;
  border: none;
  margin-top: 30px;
  margin-left: 25px;
  color: #fff;
  font-size: 18px;
  border-radius: 10px;
  font-family: Arial, Helvetica, sans-serif;
  cursor: pointer;
  transition: 0.3s ease;
  font-weight: bold;
}
.btn_submit:hover {
  color: #2ed755;
  background: #fff;
}
.btn_submit:disabled {
  color: #ffffff;
  background-color: #ffffff;
}
.create-movie .date-show {
  display: inline-block;
}
.create-movie .date-show-time {
  display: inline-block;
  margin-top: 10px;
}

.create-movie label {
  color: rgb(0, 0, 0);
}
.create-movie .form-select {
  margin: 0 1rem;
  padding: var(--btn-padding);
  font-size: 1rem;
}
.create-movie .form-select ::selection {
  color: #2ed755;
}
.list-items {
  list-style: none;
  padding: 5px 5px;
}
.list-items :hover {
  color: #ff7200;
}
</style>
