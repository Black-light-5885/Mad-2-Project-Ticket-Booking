<template>
  <div class="body">
    <div class="wrapper">
      <div class="error" v-show="error">
        <p>{{ error_msg }}</p>
      </div>
      <form @submit.prevent="login">
        <h1>Login</h1>
        <div class="input-box">
          <input
            type="text"
            v-model="logindata.user_name"
            placeholder="Enter User Name"
            required
          />
        </div>
        <div class="input-box">
          <input
            type="password"
            v-model="logindata.password"
            placeholder="Enter Password"
            required
          />
        </div>
        <div class="remember-forgot">
          <label><input type="checkbox" /> Remember me</label>
        </div>

        <button class="btn_submit">Login</button>
        <div class="register-link">
          <p>
            Don't have account?
            <a href="/register"> Register</a> Here
          </p>
        </div>
      </form>
    </div>
  </div>
</template>
<script>
export default {
  data() {
    return {
      logindata: {
        user_name: "",
        password: "",
      },
      error: false,
      error_msg: "",
    };
  },
  methods: {
    login: function () {
      const data = {
        user_name: this.logindata.user_name,
        password: this.logindata.password,
        time: Date.now(),
      };
      fetch("http://127.0.0.1:5000/app/api/login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      })
        .then((res) => {
          if (res.ok) {
            return res.json();
          } else {
            throw new Error("User Name or Password is wrong");
          }
        })
        .then((data) => {
          console.log(data.admin);
          localStorage.setItem("token", data.token);
          if (!data.admin) {
            this.$router.push({
              name: "User_Home",
              params: { user_name: this.logindata.user_name },
            });
          } else {
            this.$router.push({
              name: "Admin_Home",
              params: { user_name: this.logindata.user_name },
            });
          }
        })
        .catch((er) => {
          this.error = true;
          this.error_msg = er.message;
          console.log(er);
        });
    },
  },
  created() {
    localStorage.clear();
  },
};
</script>

<style scoped>
* {
  margin: 0%;
  padding: 0%;
  box-sizing: border-box;
  font-family: sans-serif;
}
.body {
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 97.5vh;
  background: url(./dummy/check.jpg) no-repeat;
  background-size: cover;
  background-position: center;
}
.wrapper {
  width: 420px;
  background: transparent;
  border: 2px solid rgba(255, 255, 255, 0.2);
  backdrop-filter: blur(20px);
  box-shadow: 0 0 10 rgba(0, 0, 0, 0.2);
  color: #ffff;
  border-radius: 10px;
  padding: 30px 40px;
}
.wrapper h1 {
  font-size: 36px;
  text-align: center;
}
.wrapper .error p {
  color: #ff7200;
}
.wrapper .input-box {
  position: relative;
  width: 100%;
  height: 50px;
  margin: 30px 0;
}
.input-box input {
  width: 100%;
  height: 100%;
  background: transparent;
  border: none;
  outline: none;
  border: 2px solid rgba(255, 255, 255, 0.2);
  border-radius: 40px;
  font-size: 16px;
  color: #ffff;
  padding: 20px 45px 20px 20px;
}
.input-box input::placeholder {
  color: #ffff;
}

.wrapper .remember-forgot {
  display: flex;
  justify-content: space-between;
  font-size: 14.5px;
  margin: -15px 0 15px;
}
.remember-forgot label input {
  accent-color: #ffff;
  margin-right: 3px;
}
.remember-forgot a {
  color: white;
  text-decoration: none;
}
.remember-forgot a:hover {
  color: rgb(117, 231, 24);
  text-decoration: underline;
}

.wrapper .btn_submit {
  width: 100%;
  height: 45px;
  background: #fff;
  border: none;
  outline: none;
  border-radius: 40px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
  cursor: pointer;
  font-size: 16px;
  color: #333;
  font-weight: 600;
}
.btn_submit:hover {
  background: #ff7200;
}
.wrapper .register-link {
  font-size: 14.5px;
  text-align: center;
  margin: 20px 0 15px;
}

.register-link a {
  color: #ff7200;
  text-decoration: none;
  font-weight: 400;
}
.register-link a:hover {
  text-decoration: underline;
}
</style>
