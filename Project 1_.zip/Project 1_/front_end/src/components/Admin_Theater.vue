<template>
  <div>
    <div class="nav-fnav">
      <div class="left">
        <img src="./dummy/logo3.png" alt="" />
        <input
          type="text"
          placeholder="Search for Movies, Theaters, shows etc.."
        />
      </div>

      <div class="right">
        <button>
          <router-link to="/login"><a>Logout</a></router-link>
        </button>
      </div>
    </div>

    <div class="nav-sec-nav">
      <div class="s-left">
        <router-link
          :to="{ name: 'Admin_Home', params: { uer_name: this.user_name } }"
          ><a>Home</a></router-link
        >

        <router-link
          :to="{
            name: 'Admin_Movies',
            params: { user_name: this.user_name },
          }"
          ><a>Movies</a></router-link
        >

        <router-link
          :to="{
            name: 'Admin_Theaters',
            params: { user_name: this.user_name },
          }"
          ><a>Theaters</a></router-link
        >
        <router-link
          :to="{
            name: 'Admin_Shows',
            params: { user_name: this.user_name },
          }"
          ><a>Shows</a></router-link
        >
      </div>
      <div class="s-right">
        <router-link
          :to="{
            name: 'Create_Movie',
            params: { user_name: this.user_name },
          }"
          ><a>Add Movie</a></router-link
        >
        <router-link
          :to="{
            name: 'Create_Theater',
            params: { user_name: this.user_name },
          }"
          ><a>Add Theater</a></router-link
        >
        <router-link
          :to="{
            name: 'Create_Show',
            params: { user_name: this.user_name },
          }"
          ><a>Add Show</a></router-link
        >
        <router-link
          :to="{
            name: 'User_Profile',
            params: { user_name: this.user_name },
          }"
        >
          <a>Profile</a></router-link
        >
      </div>
    </div>
    <div class="Headline">
      <h2>Theater Management</h2>
    </div>
    <div class="container">
      <div class="content">
        <div class="card" v-for="theater in theaters" :key="theater.id">
          <div class="card-content">
            <div class="theater-name">
              <h2 class="name">{{ theater.name }}</h2>
            </div>
            <div class="capacity">
              <h4><span>City :</span> {{ theater.place }}</h4>
              <h4><span>Location :</span> {{ theater.location }}</h4>
            </div>
            <div class="capacity">
              <h4><span>Shows :</span> {{ theater.shows_count }}</h4>
              <h4><span>Capacity :</span> {{ theater.capacity }}</h4>
            </div>
            <div class="button">
              <button class="delete" @click="deleteTheater(theater)">
                Delete
              </button>
              <button class="edit" @click="editTheater(theater)">Edit</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import Swal from "sweetalert2";
export default {
  props: {
    user_name: {
      type: String,
      required: true,
    },
  },
  data() {
    return {
      token: "",
      theaters: [],
      user: {
        full_name: "",
        username: "",
        admin: null,
      },
    };
  },
  methods: {
    editTheater(m) {
      const id = String(m.id);
      this.$router.push({
        name: "Edit_Theater",
        params: { user_name: this.user_name, id: id },
      });
    },
    deleteTheater(a) {
      Swal.fire({
        title: "Are you sure?",
        text: "All the shows which are linked with this Theater will also get Deleted. You won't be able to revert this!",
        icon: "warning",
        showCancelButton: true,
        confirmButtonColor: "#3085d6",
        cancelButtonColor: "#d33",
        confirmButtonText: "Yes, delete it!",
      }).then((result) => {
        if (result.isConfirmed) {
          const b = this.theaters.indexOf(a);
          const t_id = a.id;
          this.theaters.splice(b, 1);
          fetch(`http://127.0.0.1:5000/app/api/theater/${t_id}`, {
            method: "DELETE",
            headers: {
              Authorization: `Bearer ${this.token}`,
            },
          })
            .then((res) => {
              return res.json();
            })
            .then((data) => {
              if (data == "Deleted successfully") {
                Swal.fire("Deleted!", "Theater has been deleted.", "success");
              }
            });
          Swal.fire("Something is wrong!", "Not deleted.", "failed");
        }
      });
    },
    getTheater() {
      console.log("called");
      fetch("http://127.0.0.1:5000/app/api/theater", {
        method: "GET",
        headers: {
          Authorization: `Bearer ${this.token}`,
        },
      })
        .then((res) => {
          return res.json();
        })
        .then((data) => {
          if (data.msg === "Token has expired") {
            Swal.fire({
              icon: "error",
              title: "Session Exparired",
              text: "Login again",
            });
            this.$router.push("/login");
          }
          console.log(data);
          this.theaters = data.theaters;
        });
    },
  },
  created() {
    const token = localStorage.getItem("token");
    if (token == null) {
      this.$router.push("/login");
    }
    this.token = token;
    this.getTheater();
  },
};
</script>

<style scoped>
* {
  margin: 0%;
  padding: 0%;
}

.nav-fnav {
  display: flex;
  justify-content: center;
  justify-content: space-around;
  padding: 15px;
  color: white;
  background-color: rgb(42, 42, 68);
}

.nav-fnav .left {
  display: flex;
  align-items: center;
}

.left input {
  margin-inline: 11px;
  width: 320px;
  height: 33px;
  border: none;
  outline: none;
  text-align: center;
  border-radius: 3px;
}

.nav-fnav .right {
  display: flex;
  align-items: center;
}
.right a {
  margin-inline: 2px;
  font-size: 15px;
  text-decoration: none;
  color: white;
}
.left img {
  width: 170px;
  height: 60px;
}
.right button {
  margin-inline: 2px;
  width: 80px;
  height: 27px;
  border: none;
  border-radius: 5px;
  background-color: rgb(19, 131, 223);
  color: white;
  text-decoration: none;
  cursor: pointer;
  transition: 0.3s;
}
.right button:hover {
  background-color: #ff7200;
}
.nav-sec-nav {
  display: flex;
  justify-content: center;
  justify-content: space-around;
  padding: 10px;
  background-color: rgb(26, 26, 48);
  color: white;
}

.nav-sec-nav .s-left {
  display: flex;
}
.nav-sec-nav .s-right {
  display: flex;
  text-decoration: none;
}
.nav-sec-nav a:hover {
  color: brown;
  cursor: pointer;
  font-weight: bold;
  text-decoration: none;
}
.s-left a {
  margin-inline-start: 18px;
  text-decoration: none;
  color: white;
}

.s-right a {
  margin-inline-start: 18px;
  text-decoration: none;
  color: white;
}

.Headline {
  padding: 10px;
  background-color: #3ca872af;
}
.Headline h2 {
  color: rgb(42, 42, 68);
}

.container {
  justify-content: center;
  align-items: center;
  min-height: 100vh;
}
.card {
  background: rgb(42, 42, 68);
  border: 3px solid #0ef;
  border-radius: 10px;
  width: 450px;
  height: 280px;
  margin-top: 15px;
}
.content {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
}
.card .card-content {
  position: relative;
  display: flex;
  align-items: center;
  flex-direction: column;
  padding: 30px;
}
.card .theater-name {
  display: flex;
  align-items: center;
  flex-direction: column;
  margin-top: 10px;
  color: #fff;
}
.theater-name .name {
  font-size: 30px;
  font-weight: 600;
}

.theater-name .location {
  font-size: 15px;
  font-weight: 400;
}
.card .capacity {
  display: flex;
  justify-content: space-between;
  margin-top: 18px;
  color: #fff;
}
.card .capacity span {
  color: #ff7200;
}
.card .capacity h4 {
  padding: 8px 40px;
  border-radius: 20px;
}
.card .button {
  display: flex;
  justify-content: space-around;
  width: 110%;
  margin-top: 20px;
}
.card .button button {
  background: #0ef;
  border: none;
  outline: none;
  color: #000;
  font-weight: 600;
  padding: 8px 22px;
  border-radius: 20px;
  font-size: 14px;
  cursor: pointer;
  transition: 0.3s;
}
.card .button button:hover {
  background: #fff;
}
</style>
