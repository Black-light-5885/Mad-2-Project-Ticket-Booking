import Vue from "vue";
import VueRouter from "vue-router";
import Home from "../components/Home_Page.vue";
import Login from "../components/Login_Page.vue";
import Register from "../components/Register_Page.vue";
import User from "../components/User_Page.vue";
import UserTheater from "../components/User_Theaters.vue";
import UserMovies from "../components/User_Movies.vue";
import UserBookings from "../components/User_Bookings.vue";
import AdminMovies from "../components/Admin_Movies.vue";
import AdminTheater from "../components/Admin_Theater.vue";
import AdminShows from "../components/Admin_Shows.vue";
import CreateMovie from "../components/Admin_Create_Movie.vue";
import CreateShow from "../components/Admin_Create_Show.vue";
import CreateTheater from "../components/Admin_Create_Theater.vue";
import TheaterShows from "../components/Theater_Shows.vue";
import BookTicket from "../components/Book_Ticket.vue";
import MovieTheater from "../components/Movie_Theater.vue";
import UserProfile from "../components/User_Profile.vue";
import AdminHome from "../components/Admin_Home.vue";
import EditMovie from "../components/Edit_Movie.vue";
import EditTheater from "../components/Edit_Theater.vue";

Vue.use(VueRouter);

const routes = [
  { path: "/", name: "Home-page", component: Home },

  { path: "/login", name: "Login-Page", component: Login },

  { path: "/register", name: "Register-Page", component: Register },

  {
    path: "/user/home/:user_name",
    name: "User_Home",
    component: User,
    props: true,
  },
  {
    path: "/user/movies/:user_name",
    name: "User_Movies",
    component: UserMovies,
    props: true,
  },
  {
    path: "/user/theater/:user_name",
    name: "User_Theaters",
    component: UserTheater,
    props: true,
  },
  {
    path: "/user/theater/:user_name/:movie_id/:movie_name",
    name: "Movie_Theaters",
    component: MovieTheater,
    props: true,
  },
  {
    path: "/user/theaterShows/:t_id/:user_name",
    name: "Theater_Shows",
    component: TheaterShows,
    props: true,
  },
  {
    path: "/user/BookTicket/:s_id/:user_name",
    name: "Book_Ticket",
    component: BookTicket,
    props: true,
  },
  {
    path: "/user/bookings/:user_name",
    name: "User_Bookings",
    component: UserBookings,
    props: true,
  },
  {
    path: "/user/profile/:user_name",
    name: "User_Profile",
    component: UserProfile,
    props: true,
  },
  {
    path: "/admin/movies/:user_name",
    name: "Admin_Movies",
    component: AdminMovies,
    props: true,
  },
  {
    path: "/admin/home/:user_name",
    name: "Admin_Home",
    component: AdminHome,
    props: true,
  },
  {
    path: "/admin/theaters/:user_name",
    name: "Admin_Theaters",
    component: AdminTheater,
    props: true,
  },
  {
    path: "/admin/shows/:user_name",
    name: "Admin_Shows",
    component: AdminShows,
    props: true,
  },
  {
    path: "/admin/createMovie/:user_name",
    name: "Create_Movie",
    component: CreateMovie,
    props: true,
  },
  {
    path: "/admin/EditMovie/:user_name/:id",
    name: "Edit_Movie",
    component: EditMovie,
    props: true,
  },
  {
    path: "/admin/createShow/:user_name",
    name: "Create_Show",
    component: CreateShow,
    props: true,
  },
  {
    path: "/admin/createTheater/:user_name",
    name: "Create_Theater",
    component: CreateTheater,
    props: true,
  },
  {
    path: "/admin/EditTheater/:user_name/:id",
    name: "Edit_Theater",
    component: EditTheater,
    props: true,
  },
];

const router = new VueRouter({
  mode: "history",
  base: process.env.BASE_URL,
  routes,
});

export default router;
